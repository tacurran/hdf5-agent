package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
	goref "gonum.org/v1/hdf5"
)

type Server struct {
	router *mux.Router
	port   string
}

// HDF5 Structure Models
type DatasetInfo struct {
	Name      string        `json:"name"`
	Path      string        `json:"path"`
	Type      string        `json:"type"`
	Shape     []int         `json:"shape"`
	Size      int           `json:"size"`
	Datatype  string        `json:"datatype"`
	ChunkSize []int         `json:"chunkSize,omitempty"`
	Attrs     map[string]interface{} `json:"attributes,omitempty"`
}

type GroupInfo struct {
	Name     string          `json:"name"`
	Path     string          `json:"path"`
	Type     string          `json:"type"`
	Children []interface{}   `json:"children"`
	Attrs    map[string]interface{} `json:"attributes,omitempty"`
}

type FileStructure struct {
	Name     string        `json:"name"`
	Path     string        `json:"path"`
	Type     string        `json:"type"`
	Children []interface{} `json:"children"`
}

type DatasetData struct {
	Name   string          `json:"name"`
	Path   string          `json:"path"`
	Data   interface{}     `json:"data"`
	Shape  []int           `json:"shape"`
	Type   string          `json:"type"`
	Attrs  map[string]interface{} `json:"attributes,omitempty"`
}

type UpdateRequest struct {
	Path string      `json:"path"`
	Data interface{} `json:"data"`
	Indices []int   `json:"indices,omitempty"`
}

// NewServer creates a new server instance
func NewServer(port string) *Server {
	return &Server{
		router: mux.NewRouter(),
		port:   port,
	}
}

// setupRoutes configures all API routes
func (s *Server) setupRoutes() {
	s.router.HandleFunc("/api/files", s.listFiles).Methods("GET")
	s.router.HandleFunc("/api/file/open", s.openFile).Methods("POST")
	s.router.HandleFunc("/api/file/structure", s.getFileStructure).Methods("GET")
	s.router.HandleFunc("/api/dataset/read", s.readDataset).Methods("GET")
	s.router.HandleFunc("/api/dataset/update", s.updateDataset).Methods("POST")
	s.router.HandleFunc("/api/dataset/slice", s.sliceDataset).Methods("POST")
	s.router.HandleFunc("/api/file/create", s.createFile).Methods("POST")
	s.router.HandleFunc("/api/file/delete", s.deleteFile).Methods("DELETE")
	s.router.HandleFunc("/api/health", s.health).Methods("GET")
}

// listFiles returns available HDF5 files in the current directory
func (s *Server) listFiles(w http.ResponseWriter, r *http.Request) {
	files, err := os.ReadDir(".")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var hdf5Files []map[string]string
	for _, f := range files {
		if !f.IsDir() && (strings.HasSuffix(f.Name(), ".h5") || strings.HasSuffix(f.Name(), ".hdf5")) {
			info, _ := f.Info()
			hdf5Files = append(hdf5Files, map[string]string{
				"name": f.Name(),
				"size": fmt.Sprintf("%d", info.Size()),
				"path": f.Name(),
			})
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(hdf5Files)
}

// openFile opens an HDF5 file and returns its structure
func (s *Server) openFile(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Path string `json:"path"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	file, err := goref.OpenFile(req.Path, goref.F_ACC_RDONLY)
	if err != nil {
		http.Error(w, "Failed to open file: "+err.Error(), http.StatusBadRequest)
		return
	}
	defer file.Close()

	structure := s.buildFileStructure(file, req.Path)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(structure)
}

// getFileStructure returns the structure of an open file
func (s *Server) getFileStructure(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("path")
	if filePath == "" {
		http.Error(w, "Missing path parameter", http.StatusBadRequest)
		return
	}

	file, err := goref.OpenFile(filePath, goref.F_ACC_RDONLY)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	structure := s.buildFileStructure(file, filePath)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(structure)
}

// buildFileStructure recursively builds the HDF5 file structure
func (s *Server) buildFileStructure(parent *goref.File, path string) *FileStructure {
	structure := &FileStructure{
		Name: filepath.Base(path),
		Path: path,
		Type: "file",
	}

	structure.Children = s.buildGroupStructure(parent, "/")
	return structure
}

// buildGroupStructure recursively builds group structures
func (s *Server) buildGroupStructure(obj *goref.File, path string) []interface{} {
	var children []interface{}

	err := obj.VisitObjects(func(name string) error {
		fullPath := path + name
		
		// Check if it's a group or dataset
		obj := obj.Object(name)
		if obj == nil {
			return nil
		}
		defer obj.Close()

		switch obj.ObjectType() {
		case goref.H5O_TYPE_GROUP:
			group, _ := obj.AsGroup()
			if group != nil {
				defer group.Close()
				
				groupInfo := &GroupInfo{
					Name:   name,
					Path:   fullPath,
					Type:   "group",
					Attrs:  extractAttributes(group),
				}
				
				groupInfo.Children = s.buildGroupStructure(group, fullPath+"/")
				children = append(children, groupInfo)
			}

		case goref.H5O_TYPE_DATASET:
			dataset, _ := obj.AsDataset()
			if dataset != nil {
				defer dataset.Close()
				
				datasetInfo := &DatasetInfo{
					Name:     name,
					Path:     fullPath,
					Type:     "dataset",
					Shape:    getDatasetShape(dataset),
					Size:     int(dataset.Space().SimpleExtentNPoints()),
					Datatype: getDatasetType(dataset),
					Attrs:    extractAttributes(dataset),
				}
				
				children = append(children, datasetInfo)
			}
		}

		return nil
	})

	if err != nil {
		log.Printf("Error building structure: %v", err)
	}

	return children
}

// readDataset reads dataset values from an HDF5 file
func (s *Server) readDataset(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("file")
	datasetPath := r.URL.Query().Get("path")

	if filePath == "" || datasetPath == "" {
		http.Error(w, "Missing parameters", http.StatusBadRequest)
		return
	}

	file, err := goref.OpenFile(filePath, goref.F_ACC_RDONLY)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	dataset, err := file.OpenDataset(datasetPath)
	if err != nil {
		http.Error(w, "Failed to open dataset", http.StatusBadRequest)
		return
	}
	defer dataset.Close()

	data := s.readDatasetValues(dataset)
	
	response := DatasetData{
		Name:  filepath.Base(datasetPath),
		Path:  datasetPath,
		Data:  data,
		Shape: getDatasetShape(dataset),
		Type:  getDatasetType(dataset),
		Attrs: extractAttributes(dataset),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// readDatasetValues reads actual data from dataset
func (s *Server) readDatasetValues(dataset *goref.Dataset) interface{} {
	space := dataset.Space()
	dtype := dataset.Datatype()
	shape := getDatasetShape(dataset)
	npoints := space.SimpleExtentNPoints()

	defer dtype.Close()

	// Limit reading to prevent memory issues
	if npoints > 100000 {
		return map[string]interface{}{
			"truncated": true,
			"message":   fmt.Sprintf("Dataset too large (%d points). Showing preview only.", npoints),
			"preview":   s.readDatasetPreview(dataset),
		}
	}

	switch dtype.Class() {
	case goref.H5T_FLOAT:
		data := make([]float64, npoints)
		dataset.Read(&data)
		if len(shape) == 1 {
			return data
		}
		return reshape(data, shape)

	case goref.H5T_INTEGER:
		data := make([]int64, npoints)
		dataset.Read(&data)
		if len(shape) == 1 {
			return data
		}
		return reshape(data, shape)

	case goref.H5T_STRING:
		data := make([]string, npoints)
		dataset.Read(&data)
		if len(shape) == 1 {
			return data
		}
		return reshape(data, shape)

	default:
		return "Unsupported data type"
	}
}

// readDatasetPreview reads a preview of large datasets
func (s *Server) readDatasetPreview(dataset *goref.Dataset) interface{} {
	// Read only first 100 elements as preview
	dtype := dataset.Datatype()
	defer dtype.Close()

	space := dataset.Space()
	shape := getDatasetShape(dataset)
	
	// Create a small selection
	selectShape := make([]int, len(shape))
	for i, v := range shape {
		selectShape[i] = v
		if selectShape[i] > 10 {
			selectShape[i] = 10
		}
	}

	switch dtype.Class() {
	case goref.H5T_FLOAT:
		data := make([]float64, 100)
		dataset.Read(&data[:10])
		return data[:10]
	case goref.H5T_INTEGER:
		data := make([]int64, 100)
		dataset.Read(&data[:10])
		return data[:10]
	default:
		return nil
	}
}

// updateDataset updates values in a dataset
func (s *Server) updateDataset(w http.ResponseWriter, r *http.Request) {
	var req UpdateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	filePath := r.URL.Query().Get("file")
	if filePath == "" {
		http.Error(w, "Missing file parameter", http.StatusBadRequest)
		return
	}

	file, err := goref.OpenFile(filePath, goref.F_ACC_RDWR)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	dataset, err := file.OpenDataset(req.Path)
	if err != nil {
		http.Error(w, "Failed to open dataset", http.StatusBadRequest)
		return
	}
	defer dataset.Close()

	// Write data back to dataset
	err = s.writeDatasetValues(dataset, req.Data, req.Indices)
	if err != nil {
		http.Error(w, "Failed to write data: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "success"})
}

// writeDatasetValues writes data to dataset
func (s *Server) writeDatasetValues(dataset *goref.Dataset, data interface{}, indices []int) error {
	dtype := dataset.Datatype()
	defer dtype.Close()

	switch v := data.(type) {
	case []interface{}:
		// Handle array of values
		switch dtype.Class() {
		case goref.H5T_FLOAT:
			floatData := make([]float64, len(v))
			for i, val := range v {
				if f, ok := val.(float64); ok {
					floatData[i] = f
				}
			}
			dataset.Write(floatData)
		case goref.H5T_INTEGER:
			intData := make([]int64, len(v))
			for i, val := range v {
				if f, ok := val.(float64); ok {
					intData[i] = int64(f)
				}
			}
			dataset.Write(intData)
		}
	}

	return nil
}

// sliceDataset returns a slice of dataset data
func (s *Server) sliceDataset(w http.ResponseWriter, r *http.Request) {
	var req struct {
		File   string `json:"file"`
		Path   string `json:"path"`
		Start  []int  `json:"start"`
		Count  []int  `json:"count"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	file, err := goref.OpenFile(req.File, goref.F_ACC_RDONLY)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	dataset, err := file.OpenDataset(req.Path)
	if err != nil {
		http.Error(w, "Failed to open dataset", http.StatusBadRequest)
		return
	}
	defer dataset.Close()

	// Select hyperslab
	space := dataset.Space()
	space.SelectHyperslab(goref.H5S_SELECT_SET, req.Count, req.Start)

	dtype := dataset.Datatype()
	defer dtype.Close()

	// Calculate number of elements
	npoints := 1
	for _, c := range req.Count {
		npoints *= c
	}

	var data interface{}
	switch dtype.Class() {
	case goref.H5T_FLOAT:
		fdata := make([]float64, npoints)
		dataset.Read(&fdata)
		data = fdata
	case goref.H5T_INTEGER:
		idata := make([]int64, npoints)
		dataset.Read(&idata)
		data = idata
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"data":  data,
		"shape": req.Count,
	})
}

// createFile creates a new empty HDF5 file
func (s *Server) createFile(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Filename string `json:"filename"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	file, err := goref.CreateFile(req.Filename, goref.F_ACC_EXCL)
	if err != nil {
		http.Error(w, "Failed to create file: "+err.Error(), http.StatusBadRequest)
		return
	}
	defer file.Close()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"status":   "success",
		"filename": req.Filename,
	})
}

// deleteFile deletes an HDF5 file
func (s *Server) deleteFile(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("path")
	if filePath == "" {
		http.Error(w, "Missing path parameter", http.StatusBadRequest)
		return
	}

	if err := os.Remove(filePath); err != nil {
		http.Error(w, "Failed to delete file", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "success"})
}

// health check endpoint
func (s *Server) health(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "healthy"})
}

// Helper functions
func getDatasetShape(dataset *goref.Dataset) []int {
	space := dataset.Space()
	dims, _ := space.SimpleExtentDims()
	return dims
}

func getDatasetType(dataset *goref.Dataset) string {
	dtype := dataset.Datatype()
	defer dtype.Close()

	switch dtype.Class() {
	case goref.H5T_FLOAT:
		return fmt.Sprintf("float%d", dtype.Size()*8)
	case goref.H5T_INTEGER:
		return fmt.Sprintf("int%d", dtype.Size()*8)
	case goref.H5T_STRING:
		return "string"
	default:
		return "unknown"
	}
}

func extractAttributes(obj interface{}) map[string]interface{} {
	attrs := make(map[string]interface{})
	
	// Type assertion to get attributes
	switch v := obj.(type) {
	case *goref.File:
		nAttrs := v.NumAttrs()
		for i := 0; i < nAttrs; i++ {
			attr := v.OpenAttrByIdx("", uint(i), goref.H5_INDEX_NAME, goref.H5_ITER_NATIVE)
			if attr != nil {
				defer attr.Close()
				// Read attribute values if needed
			}
		}
	case *goref.Group:
		nAttrs := v.NumAttrs()
		for i := 0; i < nAttrs; i++ {
			attr := v.OpenAttrByIdx("", uint(i), goref.H5_INDEX_NAME, goref.H5_ITER_NATIVE)
			if attr != nil {
				defer attr.Close()
			}
		}
	case *goref.Dataset:
		nAttrs := v.NumAttrs()
		for i := 0; i < nAttrs; i++ {
			attr := v.OpenAttrByIdx("", uint(i), goref.H5_INDEX_NAME, goref.H5_ITER_NATIVE)
			if attr != nil {
				defer attr.Close()
			}
		}
	}

	return attrs
}

func reshape(data interface{}, shape []int) interface{} {
	// Multi-dimensional reshape logic could be implemented here
	return data
}

// Start starts the HTTP server
func (s *Server) Start() error {
	s.setupRoutes()

	// Setup CORS
	c := cors.New(cors.Options{
		AllowedOrigins: []string{"*"},
		AllowedMethods: []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders: []string{"Content-Type", "Authorization"},
	})

	handler := c.Handler(s.router)

	log.Printf("HDF5 Agent Server starting on port %s", s.port)
	return http.ListenAndServe(":"+s.port, handler)
}

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	server := NewServer(port)
	if err := server.Start(); err != nil {
		log.Fatal(err)
	}
}
