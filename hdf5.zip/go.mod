module github.com/example/hdf5-agent

go 1.21

require (
	github.com/gorilla/mux v1.8.0
	github.com/rs/cors v1.10.1
	gonum.org/v1/hdf5 v0.14.1
)

require (
	golang.org/x/exp v0.0.0-20230817173708-d852ddb80c63 // indirect
)
