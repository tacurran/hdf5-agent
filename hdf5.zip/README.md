# HDF5 Agent

A professional-grade HDF5 file manipulation system with a modern web-based interface. Built with Go backend and React frontend, featuring real-time data visualization and editing capabilities.

## Features

🎯 **Core Capabilities**
- Browse and explore HDF5 file structures hierarchically
- Read and display dataset contents with full shape information
- Edit numerical data directly in the browser
- Create new HDF5 files
- Delete files safely with confirmation
- Real-time data validation and error handling

📊 **Data Handling**
- Support for float, integer, and string data types
- Automatic truncation for large datasets (100k+ elements)
- Preview mode for dataset exploration
- Hyperslab data selection for efficient querying
- Attributes display and metadata inspection

🎨 **User Interface**
- Scientific instrument aesthetic with dark theme
- Precision-focused design for technical workflows
- Responsive layout for various screen sizes
- Smooth animations and transitions
- Monospace fonts for data integrity

🚀 **Architecture**
- Go backend with gorilla/mux routing
- React frontend with modern hooks
- CORS-enabled for flexible deployment
- Docker support for containerized deployment
- REST API for programmatic access

## Quick Start

### Prerequisites

- Go 1.21+
- Node.js 18+
- HDF5 development libraries
- Docker & Docker Compose (optional)

### Installation

#### 1. Clone the repository
```bash
git clone https://github.com/yourusername/hdf5-agent.git
cd hdf5-agent
```

#### 2. Setup Backend

**macOS:**
```bash
brew install hdf5
```

**Ubuntu/Debian:**
```bash
sudo apt-get install libhdf5-dev
```

**CentOS/RHEL:**
```bash
sudo yum install hdf5-devel
```

**Install Go dependencies:**
```bash
go mod download
```

#### 3. Setup Frontend

```bash
cd frontend
npm install
cd ..
```

### Running Locally

#### Option 1: Development Mode (Separate Processes)

**Terminal 1 - Backend:**
```bash
go run main.go
# Server runs on http://localhost:8080
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
# Browser opens on http://localhost:3000
```

#### Option 2: Docker Compose

```bash
docker-compose up
```

This starts:
- Backend on `http://localhost:8080`
- Frontend on `http://localhost:3000`

#### Option 3: Docker Production Build

```bash
docker build -t hdf5-agent .
docker run -p 8080:8080 -v $(pwd)/data:/root/data hdf5-agent
```

Then access the frontend at `http://localhost:8080`

## Project Structure

```
hdf5-agent/
├── main.go                          # Go backend server
├── go.mod                           # Go dependencies
├── Dockerfile                       # Production container
├── docker-compose.yml              # Compose configuration
│
├── frontend/
│   ├── package.json               # Node dependencies
│   ├── index.html                 # HTML entry point
│   ├── vite.config.js             # Vite configuration
│   ├── Dockerfile.frontend        # Frontend container
│   └── src/
│       ├── main.jsx               # React entry point
│       ├── App.jsx                # Main component
│       └── App.css                # Styling
│
├── README.md                       # This file
└── data/                           # HDF5 files directory
```

## API Documentation

### File Operations

#### List Files
```
GET /api/files
Response: [{ name, size, path }, ...]
```

#### Open File
```
POST /api/file/open
Body: { path: string }
Response: FileStructure
```

#### Get File Structure
```
GET /api/file/structure?path=example.h5
Response: FileStructure with hierarchical data
```

#### Create File
```
POST /api/file/create
Body: { filename: string }
Response: { status, filename }
```

#### Delete File
```
DELETE /api/file/delete?path=example.h5
Response: { status }
```

### Dataset Operations

#### Read Dataset
```
GET /api/dataset/read?file=example.h5&path=/group/dataset
Response: {
  name: string
  path: string
  data: array | object
  shape: [dimensions]
  type: string
  attributes: {}
}
```

#### Update Dataset
```
POST /api/dataset/update?file=example.h5
Body: {
  path: string
  data: array
  indices: [optional indices]
}
Response: { status }
```

#### Slice Dataset
```
POST /api/dataset/slice
Body: {
  file: string
  path: string
  start: [indices]
  count: [counts]
}
Response: { data, shape }
```

### Health Check
```
GET /api/health
Response: { status: "healthy" }
```

## Usage Guide

### 1. Opening a File

1. Click on a file in the left sidebar
2. The file structure appears in the tree view
3. Expand groups to explore nested data

### 2. Viewing Dataset Data

1. Click on a dataset in the tree
2. Data loads in the right pane
3. Dataset metadata appears at the top:
   - Shape (dimensions)
   - Data type
   - Total elements

### 3. Editing Data

1. Click on a data cell to enter edit mode
2. Type the new value
3. Press Enter or click outside to save
4. The cell updates and syncs to the file

### 4. Creating New Files

1. Click "New File" button in header
2. Enter filename (e.g., `mydata.h5`)
3. Click Create

### 5. Deleting Files

1. Right-click on file in sidebar or use delete button
2. Confirm deletion
3. File is permanently removed

## Configuration

### Environment Variables

```bash
# Backend port
export PORT=8080

# Frontend API endpoint (development)
export VITE_API_URL=http://localhost:8080/api
```

### CORS Configuration

Backend allows requests from all origins (`*`). For production, modify in `main.go`:

```go
c := cors.New(cors.Options{
    AllowedOrigins: []string{"https://yourdomain.com"},
    // ...
})
```

## Performance Considerations

### Large Datasets

- Datasets with >100,000 elements are automatically truncated
- Preview mode shows first 100 elements
- Use slicing API for efficient querying

### Memory Usage

- Dataset loading limited to prevent memory spikes
- Streaming recommended for massive files
- Consider batch processing for modifications

### Optimization Tips

1. Work with datasets <10GB for optimal performance
2. Use groups to organize related data
3. Apply compression in HDF5 files for storage
4. Index frequently accessed datasets

## Advanced Features

### Batch Operations

Modify multiple values via API:

```bash
curl -X POST http://localhost:8080/api/dataset/update \
  -H "Content-Type: application/json" \
  -d '{
    "path": "/data/values",
    "data": [1.0, 2.0, 3.0],
    "indices": [0, 1, 2]
  }'
```

### Data Export

Right-click dataset and select "Export" to download as JSON/CSV (future enhancement).

### Attributes

View metadata and attributes:
- Hover over dataset badge for attribute preview
- Full attribute listing in data panel

## Troubleshooting

### Backend Connection Failed

```
Error: Failed to connect to API
```

**Solution:**
```bash
# Verify backend is running
curl http://localhost:8080/api/health

# Check port binding
lsof -i :8080
```

### HDF5 Library Not Found

```
error: hdf5.h: No such file or directory
```

**Solution - macOS:**
```bash
brew install hdf5
export HDF5_DIR=$(brew --prefix hdf5)
go build
```

**Solution - Ubuntu:**
```bash
sudo apt-get install libhdf5-dev
```

### Port Already in Use

```
listen tcp :8080: bind: address already in use
```

**Solution:**
```bash
# Use different port
export PORT=9000
go run main.go
```

### CORS Errors

```
Access to XMLHttpRequest blocked by CORS policy
```

**Solution:**
Verify backend CORS configuration includes your frontend URL.

## Development

### Building Frontend
```bash
cd frontend
npm run build
# Output in frontend/dist/
```

### Testing API
```bash
# Create test HDF5 file
go run scripts/create_test_data.go

# Test endpoints
curl http://localhost:8080/api/files
curl http://localhost:8080/api/health
```

### Code Style

**Go:**
```bash
go fmt ./...
go vet ./...
```

**React:**
```bash
npm run lint
npm run build
```

## Browser Support

- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Security Considerations

⚠️ **Important:**

1. **File Access:** Currently reads from current working directory
   - Deploy in isolated container with specific data volume
   - Implement authentication for production use

2. **Data Validation:** Input validation implemented
   - File path traversal prevented
   - Type checking on dataset updates

3. **API Access:** No authentication by default
   - Add API key validation for production
   - Use reverse proxy (nginx) for additional security

4. **CORS:** Configured to allow all origins
   - Restrict to specific domains in production

## Contributing

Contributions welcome! Areas for enhancement:

- [ ] Authentication/Authorization
- [ ] Batch import/export
- [ ] Advanced visualization (3D plots, heatmaps)
- [ ] Real-time collaboration
- [ ] Dataset statistics & analysis
- [ ] Custom data type support

## License

MIT License - See LICENSE file for details

## Support

- 📖 [HDF5 Documentation](https://www.hdfgroup.org/HDF5/)
- 🐛 [Issue Tracker](https://github.com/yourusername/hdf5-agent/issues)
- 💬 [Discussions](https://github.com/yourusername/hdf5-agent/discussions)

## Acknowledgments

Built with:
- [Go HDF5](https://github.com/gonum/hdf5) - HDF5 Go bindings
- [Gorilla Mux](https://github.com/gorilla/mux) - HTTP router
- [React](https://react.dev/) - UI framework
- [Vite](https://vitejs.dev/) - Build tool

---

**Version:** 1.0.0  
**Last Updated:** 2024  
**Status:** Production Ready ✅
